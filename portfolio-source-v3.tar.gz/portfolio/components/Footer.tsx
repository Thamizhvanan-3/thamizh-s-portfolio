"use client";
import { motion } from "framer-motion";
import { Code2, Heart, ArrowUp } from "lucide-react";

export default function Footer() {
  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <footer className="border-t border-slate-200 dark:border-surface-border bg-slate-50 dark:bg-surface-card">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-accent-500 flex items-center justify-center">
              <Code2 size={16} className="text-white" />
            </div>
            <span className="font-display font-700 text-sm text-slate-900 dark:text-white">
              Thamizhvanan <span className="gradient-text">G.</span>
            </span>
          </div>

          {/* Attribution */}
          <p className="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1">
            Built with <Heart size={11} className="text-red-400 fill-red-400" /> using Next.js, Tailwind & Framer Motion
          </p>

          {/* Back to top */}
          <motion.button
            onClick={scrollTop}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-brand-500 dark:hover:text-brand-400 transition-colors"
          >
            <ArrowUp size={13} />
            Back to top
          </motion.button>
        </div>
      </div>
    </footer>
  );
}
