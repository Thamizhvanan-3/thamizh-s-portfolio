"use client";
import { motion } from "framer-motion";
import { Download, Mail, GitBranch, Link2, ChevronDown, Sparkles } from "lucide-react";

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 32 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: "easeOut" as const, delay },
});

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-white dark:bg-surface-dark"
    >
      {/* Grid bg */}
      <div className="absolute inset-0 grid-bg opacity-60 dark:opacity-100" />

      {/* Glow orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-brand-500/20 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 rounded-full bg-accent-500/20 blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center">
        {/* Badge */}
        <motion.div {...fadeUp(0)} className="inline-flex items-center gap-2 px-4 py-1.5 mb-8 rounded-full border border-brand-500/30 bg-brand-500/10 text-brand-600 dark:text-brand-400 text-sm font-medium">
          <Sparkles size={14} />
          Open to Python / Django / ML roles
        </motion.div>

        {/* Name */}
        <motion.h1 {...fadeUp(0.1)} className="font-display text-5xl sm:text-6xl lg:text-7xl font-800 tracking-tight mb-4 leading-[1.05]">
          <span className="text-slate-900 dark:text-white">Thamizhvanan&nbsp;</span>
          <span style={{ background: "linear-gradient(135deg, #0e90f5, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>G.</span>
        </motion.h1>

        {/* Title */}
        <motion.div {...fadeUp(0.2)} className="flex items-center justify-center gap-3 mb-6">
          <span className="h-px w-12" style={{ background: "linear-gradient(to right, transparent, #0e90f5)" }} />
          <span className="font-mono text-lg font-medium tracking-wide" style={{ color: "#0e90f5" }}>
            Python Developer
          </span>
          <span className="h-px w-12" style={{ background: "linear-gradient(to left, transparent, #0e90f5)" }} />
        </motion.div>

        {/* Tagline */}
        <motion.p {...fadeUp(0.3)} className="text-lg sm:text-xl max-w-2xl mx-auto leading-relaxed mb-10" style={{ color: "#475569" }}>
          Building scalable web applications and solving real-world problems through{" "}
          <strong style={{ color: "#0e90f5" }}>Python</strong> and{" "}
          <strong style={{ color: "#8b5cf6" }}>Django</strong>.
        </motion.p>

        {/* CTAs */}
        <motion.div {...fadeUp(0.4)} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14">
          <a
            href="/resume.pdf"
            download
            className="group flex items-center gap-2.5 px-6 py-3.5 rounded-xl font-semibold transition-all duration-200 hover:scale-105"
            style={{ background: "linear-gradient(135deg, #0e90f5, #8b5cf6)", color: "#ffffff", boxShadow: "0 4px 24px rgba(14,144,245,0.35)" }}
          >
            <Download size={17} className="group-hover:animate-bounce" />
            Download Resume
          </a>
          <a
            href="#contact"
            className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl font-semibold transition-all duration-200 hover:scale-105"
            style={{ border: "2px solid #0e90f5", color: "#0e90f5", background: "transparent" }}
          >
            <Mail size={17} />
            Get in Touch
          </a>
        </motion.div>

        {/* Social Links */}
        <motion.div {...fadeUp(0.5)} className="flex items-center justify-center gap-4">
          <a
            href="https://linkedin.com/in/thamizhvanan-g"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-200 hover:scale-110"
            style={{ border: "1.5px solid #cbd5e1", color: "#64748b" }}
          >
            <Link2 size={18} />
          </a>
          <a
            href="https://github.com/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="GitHub"
            className="w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-200 hover:scale-110"
            style={{ border: "1.5px solid #cbd5e1", color: "#64748b" }}
          >
            <GitBranch size={18} />
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.a
        href="#about"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-slate-400 dark:text-slate-600 hover:text-brand-500 dark:hover:text-brand-400 transition-colors"
      >
        <span className="text-xs font-medium tracking-widest uppercase">Scroll</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
        >
          <ChevronDown size={18} />
        </motion.div>
      </motion.a>
    </section>
  );
}
